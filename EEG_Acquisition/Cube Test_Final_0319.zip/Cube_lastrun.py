#!/usr/bin/env python2
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy2 Experiment Builder (v1.83.04), 2016_03_19_0900
If you publish work using this script please cite the relevant PsychoPy publications
  Peirce, JW (2007) PsychoPy - Psychophysics software in Python. Journal of Neuroscience Methods, 162(1-2), 8-13.
  Peirce, JW (2009) Generating stimuli for neuroscience using PsychoPy. Frontiers in Neuroinformatics, 2:10. doi: 10.3389/neuro.11.010.2008
"""

from __future__ import division  # so that 1/3=0.333 instead of 1/3=0
from psychopy import locale_setup, visual, core, data, event, logging, sound, gui
from psychopy.constants import *  # things like STARTED, FINISHED
import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import sin, cos, tan, log, log10, pi, average, sqrt, std, deg2rad, rad2deg, linspace, asarray
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys # to get file system encoding

# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__)).decode(sys.getfilesystemencoding())
os.chdir(_thisDir)

# Store info about the experiment session
expName = 'Cube'  # from the Builder filename that created this script
expInfo = {'participant':'', 'session':'001'}
dlg = gui.DlgFromDict(dictionary=expInfo, title=expName)
if dlg.OK == False: core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' %(expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath=u'K:\\0319_Testbed\\Cube Test_Final_0319\\Cube.psyexp',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
#save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(size=(1920, 1080), fullscr=True, screen=0, allowGUI=False, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True,
    )
# store frame rate of monitor if we can measure it successfully
expInfo['frameRate']=win.getActualFrameRate()
if expInfo['frameRate']!=None:
    frameDur = 1.0/round(expInfo['frameRate'])
else:
    frameDur = 1.0/60.0 # couldn't get a reliable measure so guess

# Initialize components for Routine "start_test"
start_testClock = core.Clock()
import win32api
import win32con
import time

def MouseClick(x, y) :
    x = int(x)
    y = int(y)
    win32api.SetCursorPos((x,y))
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTDOWN,x,y,0,0)
    win32api.mouse_event(win32con.MOUSEEVENTF_LEFTUP,x,y,0,0)

def EnterPress():
    win32api.keybd_event(0X0D, 0,0,0) 
    time.sleep(.05) 
    win32api.keybd_event(0X0D,0 ,win32con.KEYEVENTF_KEYUP ,0) 


# Initialize components for Routine "trialSetting"
trialSettingClock = core.Clock()
nDumm=1
nInst=1
nTest=1
nMouse=1
nTimeOut=1

# Initialize components for Routine "TimeOut"
TimeOutClock = core.Clock()
image_4 = visual.ImageStim(win=win, name='image_4',
    image='sin', mask=None,
    ori=0, pos=[0, 0], size=[1.5, 1.5],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

timer2 = '30'
text_2 = visual.TextStim(win=win, ori=0, name='text_2',
    text='default text',    font='Arial',
    pos=[0, 0.85], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-2.0)

# Initialize components for Routine "dummy"
dummyClock = core.Clock()
dummy_start = visual.TextStim(win=win, ori=0, name='dummy_start',
    text='+',    font='Arial',
    pos=[0, 0], height=0.5, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)
image = visual.ImageStim(win=win, name='image',
    image='sin', mask=None,
    ori=0, pos=[0, 0], size=[1.6, 1.6],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)


# Initialize components for Routine "feed"
feedClock = core.Clock()
#msg variable just needs some value at start
feed=""
message = visual.TextStim(win=win, ori=0, name='message',
    text='default text',    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)

# Initialize components for Routine "Instruction"
InstructionClock = core.Clock()
image_2 = visual.ImageStim(win=win, name='image_2',
    image='sin', mask=None,
    ori=0, pos=[0, 0], size=[1.5, 1.5],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=0.0)

# Initialize components for Routine "Test"
TestClock = core.Clock()
test_start_txt = visual.TextStim(win=win, ori=0, name='test_start_txt',
    text='+',    font='Arial',
    pos=[0, 0], height=0.5, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=0.0)
image_3 = visual.ImageStim(win=win, name='image_3',
    image='sin', mask=None,
    ori=0, pos=[0, 0], size=[1.5, 1.5],
    color=[1,1,1], colorSpace='rgb', opacity=1,
    flipHoriz=False, flipVert=False,
    texRes=128, interpolate=True, depth=-1.0)
Timer = visual.TextStim(win=win, ori=0, name='Timer',
    text='default text',    font='Arial',
    pos=[0, 0.85], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-3.0)


timer = '5'

data_string = 'prob,rt,corr\n'



# Initialize components for Routine "MouseEvent"
MouseEventClock = core.Clock()

text = visual.TextStim(win=win, ori=0, name='text',
    text=None,    font='Arial',
    pos=[0, 0], height=0.1, wrapWidth=None,
    color='white', colorSpace='rgb', opacity=1,
    depth=-1.0)

# Initialize components for Routine "end_test"
end_testClock = core.Clock()
from matplotlib import pyplot
import pandas as pd

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

#------Prepare to start Routine "start_test"-------
t = 0
start_testClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat

# keep track of which components have finished
start_testComponents = []
for thisComponent in start_testComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "start_test"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = start_testClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in start_testComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "start_test"-------
for thisComponent in start_testComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# the Routine "start_test" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of conditions etc
trials = data.TrialHandler(nReps=1, method='sequential', 
    extraInfo=expInfo, originPath=-1,
    trialList=data.importConditions('Settings_ConCube.xlsx'),
    seed=None, name='trials')
thisExp.addLoop(trials)  # add the loop to the experiment
thisTrial = trials.trialList[0]  # so we can initialise stimuli with some values
# abbreviate parameter names if possible (e.g. rgb=thisTrial.rgb)
if thisTrial != None:
    for paramName in thisTrial.keys():
        exec(paramName + '= thisTrial.' + paramName)

for thisTrial in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb = thisTrial.rgb)
    if thisTrial != None:
        for paramName in thisTrial.keys():
            exec(paramName + '= thisTrial.' + paramName)
    
    #------Prepare to start Routine "trialSetting"-------
    t = 0
    trialSettingClock.reset()  # clock 
    frameN = -1
    # update component parameters for each repeat
    if(Type=='Inst'):
        nInst=1
        nDumm=0
        nTest=0
        nMouse=0
        nTimeOut=0
    
    elif(Type=='Dumm'):
        nInst=0
        nDumm=1
        nTest=0
        nMouse=0
        nTimeOut=0
    
    elif(Type=='Test'):
        nInst=0
        nDumm=0
        nTest=1
        nMouse=0
        nTimeOut=0
    
    elif(Type=='Mouse'):
        nInst=0
        nDumm=0
        nTest=0
        nMouse=1
        nTimeOut=0
    
    elif(Type=='TimeOut'):
        nInst=0
        nDumm=0
        nTest=0
        nMouse=0
        nTimeOut=1
    
    # keep track of which components have finished
    trialSettingComponents = []
    for thisComponent in trialSettingComponents:
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    
    #-------Start Routine "trialSetting"-------
    continueRoutine = True
    while continueRoutine:
        # get current time
        t = trialSettingClock.getTime()
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in trialSettingComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # check for quit (the Esc key)
        if endExpNow or event.getKeys(keyList=["escape"]):
            core.quit()
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    #-------Ending Routine "trialSetting"-------
    for thisComponent in trialSettingComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    
    # the Routine "trialSetting" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # set up handler to look after randomisation of conditions etc
    TimeOut_loop = data.TrialHandler(nReps=nTimeOut, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='TimeOut_loop')
    thisExp.addLoop(TimeOut_loop)  # add the loop to the experiment
    thisTimeOut_loop = TimeOut_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb=thisTimeOut_loop.rgb)
    if thisTimeOut_loop != None:
        for paramName in thisTimeOut_loop.keys():
            exec(paramName + '= thisTimeOut_loop.' + paramName)
    
    for thisTimeOut_loop in TimeOut_loop:
        currentLoop = TimeOut_loop
        # abbreviate parameter names if possible (e.g. rgb = thisTimeOut_loop.rgb)
        if thisTimeOut_loop != None:
            for paramName in thisTimeOut_loop.keys():
                exec(paramName + '= thisTimeOut_loop.' + paramName)
        
        #------Prepare to start Routine "TimeOut"-------
        t = 0
        TimeOutClock.reset()  # clock 
        frameN = -1
        # update component parameters for each repeat
        image_4.setImage(Img)
        timeoutPeriod = 60
        timerStart = timeoutPeriod -10
        routineTimer.add(timeoutPeriod)
        
        # keep track of which components have finished
        TimeOutComponents = []
        TimeOutComponents.append(image_4)
        TimeOutComponents.append(text_2)
        for thisComponent in TimeOutComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        #-------Start Routine "TimeOut"-------
        continueRoutine = True
        while continueRoutine:
            # get current time
            t = TimeOutClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_4* updates
            if t >= 0.0 and image_4.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_4.tStart = t  # underestimates by a little under one frame
                image_4.frameNStart = frameN  # exact frame index
                image_4.setAutoDraw(True)
            if image_4.status == STARTED and t >= (0.0 + (timeoutPeriod-win.monitorFramePeriod*0.75)): #most of one frame period left
                image_4.setAutoDraw(False)
            timer2 = '%d' % routineTimer.getTime()
            
            # *text_2* updates
            if t >= timerStart and text_2.status == NOT_STARTED:
                # keep track of start time/frame for later
                text_2.tStart = t  # underestimates by a little under one frame
                text_2.frameNStart = frameN  # exact frame index
                text_2.setAutoDraw(True)
            if text_2.status == STARTED and t >= (timerStart + (10-win.monitorFramePeriod*0.75)): #most of one frame period left
                text_2.setAutoDraw(False)
            if text_2.status == STARTED:  # only update if being drawn
                text_2.setText(timer2, log=False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in TimeOutComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        #-------Ending Routine "TimeOut"-------
        for thisComponent in TimeOutComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        
        routineTimer.reset()
        # the Routine "TimeOut" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed nTimeOut repeats of 'TimeOut_loop'
    
    
    # set up handler to look after randomisation of conditions etc
    Dummy_loop = data.TrialHandler(nReps=nDumm, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='Dummy_loop')
    thisExp.addLoop(Dummy_loop)  # add the loop to the experiment
    thisDummy_loop = Dummy_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb=thisDummy_loop.rgb)
    if thisDummy_loop != None:
        for paramName in thisDummy_loop.keys():
            exec(paramName + '= thisDummy_loop.' + paramName)
    
    for thisDummy_loop in Dummy_loop:
        currentLoop = Dummy_loop
        # abbreviate parameter names if possible (e.g. rgb = thisDummy_loop.rgb)
        if thisDummy_loop != None:
            for paramName in thisDummy_loop.keys():
                exec(paramName + '= thisDummy_loop.' + paramName)
        
        #------Prepare to start Routine "dummy"-------
        t = 0
        dummyClock.reset()  # clock 
        frameN = -1
        routineTimer.add(12.000000)
        # update component parameters for each repeat
        image.setImage(Img)
        resp_dummy = event.BuilderKeyResponse()  # create an object of type KeyResponse
        resp_dummy.status = NOT_STARTED
        
        resp_dummy.rt=10
        resp_dummy.corr=0
        # keep track of which components have finished
        dummyComponents = []
        dummyComponents.append(dummy_start)
        dummyComponents.append(image)
        dummyComponents.append(resp_dummy)
        for thisComponent in dummyComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        #-------Start Routine "dummy"-------
        continueRoutine = True
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = dummyClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *dummy_start* updates
            if t >= 0.0 and dummy_start.status == NOT_STARTED:
                # keep track of start time/frame for later
                dummy_start.tStart = t  # underestimates by a little under one frame
                dummy_start.frameNStart = frameN  # exact frame index
                dummy_start.setAutoDraw(True)
            if dummy_start.status == STARTED and t >= (0.0 + (2-win.monitorFramePeriod*0.75)): #most of one frame period left
                dummy_start.setAutoDraw(False)
            
            # *image* updates
            if t >= 2 and image.status == NOT_STARTED:
                # keep track of start time/frame for later
                image.tStart = t  # underestimates by a little under one frame
                image.frameNStart = frameN  # exact frame index
                image.setAutoDraw(True)
            if image.status == STARTED and t >= (2 + (10-win.monitorFramePeriod*0.75)): #most of one frame period left
                image.setAutoDraw(False)
            
            # *resp_dummy* updates
            if t >= 2 and resp_dummy.status == NOT_STARTED:
                # keep track of start time/frame for later
                resp_dummy.tStart = t  # underestimates by a little under one frame
                resp_dummy.frameNStart = frameN  # exact frame index
                resp_dummy.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(resp_dummy.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
            if resp_dummy.status == STARTED and t >= (2 + (10-win.monitorFramePeriod*0.75)): #most of one frame period left
                resp_dummy.status = STOPPED
            if resp_dummy.status == STARTED:
                theseKeys = event.getKeys(keyList=['left', 'right'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    resp_dummy.keys = theseKeys[-1]  # just the last key pressed
                    resp_dummy.rt = resp_dummy.clock.getTime()
                    # was this 'correct'?
                    if (resp_dummy.keys == str(CorrKey)) or (resp_dummy.keys == CorrKey):
                        resp_dummy.corr = 1
                    else:
                        resp_dummy.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in dummyComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        #-------Ending Routine "dummy"-------
        for thisComponent in dummyComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if resp_dummy.keys in ['', [], None]:  # No response was made
           resp_dummy.keys=None
           # was no response the correct answer?!
           if str(CorrKey).lower() == 'none': resp_dummy.corr = 1  # correct non-response
           else: resp_dummy.corr = 0  # failed to respond (incorrectly)
        # store data for Dummy_loop (TrialHandler)
        Dummy_loop.addData('resp_dummy.keys',resp_dummy.keys)
        Dummy_loop.addData('resp_dummy.corr', resp_dummy.corr)
        if resp_dummy.keys != None:  # we had a response
            Dummy_loop.addData('resp_dummy.rt', resp_dummy.rt)
        
        
        #------Prepare to start Routine "feed"-------
        t = 0
        feedClock.reset()  # clock 
        frameN = -1
        routineTimer.add(3.000000)
        # update component parameters for each repeat
        if resp_dummy.corr:#stored on last run routine
          feed="Good! \n \n \n Response time = %.3f" %(resp_dummy.rt)
        else:
          feed="Wrong \n \n Response time = %.3f" %(resp_dummy.rt)
        message.setText(feed)
        # keep track of which components have finished
        feedComponents = []
        feedComponents.append(message)
        for thisComponent in feedComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        #-------Start Routine "feed"-------
        continueRoutine = True
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = feedClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            
            # *message* updates
            if t >= 0.0 and message.status == NOT_STARTED:
                # keep track of start time/frame for later
                message.tStart = t  # underestimates by a little under one frame
                message.frameNStart = frameN  # exact frame index
                message.setAutoDraw(True)
            if message.status == STARTED and t >= (0.0 + (3-win.monitorFramePeriod*0.75)): #most of one frame period left
                message.setAutoDraw(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in feedComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        #-------Ending Routine "feed"-------
        for thisComponent in feedComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        
    # completed nDumm repeats of 'Dummy_loop'
    
    
    # set up handler to look after randomisation of conditions etc
    Inst_loop = data.TrialHandler(nReps=nInst, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='Inst_loop')
    thisExp.addLoop(Inst_loop)  # add the loop to the experiment
    thisInst_loop = Inst_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb=thisInst_loop.rgb)
    if thisInst_loop != None:
        for paramName in thisInst_loop.keys():
            exec(paramName + '= thisInst_loop.' + paramName)
    
    for thisInst_loop in Inst_loop:
        currentLoop = Inst_loop
        # abbreviate parameter names if possible (e.g. rgb = thisInst_loop.rgb)
        if thisInst_loop != None:
            for paramName in thisInst_loop.keys():
                exec(paramName + '= thisInst_loop.' + paramName)
        
        #------Prepare to start Routine "Instruction"-------
        t = 0
        InstructionClock.reset()  # clock 
        frameN = -1
        # update component parameters for each repeat
        image_2.setImage(Img)
        key_resp_2 = event.BuilderKeyResponse()  # create an object of type KeyResponse
        key_resp_2.status = NOT_STARTED
        # keep track of which components have finished
        InstructionComponents = []
        InstructionComponents.append(image_2)
        InstructionComponents.append(key_resp_2)
        for thisComponent in InstructionComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        #-------Start Routine "Instruction"-------
        continueRoutine = True
        while continueRoutine:
            # get current time
            t = InstructionClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *image_2* updates
            if t >= 0.0 and image_2.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_2.tStart = t  # underestimates by a little under one frame
                image_2.frameNStart = frameN  # exact frame index
                image_2.setAutoDraw(True)
            
            # *key_resp_2* updates
            if t >= 0.0 and key_resp_2.status == NOT_STARTED:
                # keep track of start time/frame for later
                key_resp_2.tStart = t  # underestimates by a little under one frame
                key_resp_2.frameNStart = frameN  # exact frame index
                key_resp_2.status = STARTED
                # keyboard checking is just starting
                event.clearEvents(eventType='keyboard')
            if key_resp_2.status == STARTED:
                theseKeys = event.getKeys(keyList=['space'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    # a response ends the routine
                    continueRoutine = False
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in InstructionComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        #-------Ending Routine "Instruction"-------
        for thisComponent in InstructionComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # the Routine "Instruction" was not non-slip safe, so reset the non-slip timer
        routineTimer.reset()
    # completed nInst repeats of 'Inst_loop'
    
    
    # set up handler to look after randomisation of conditions etc
    Test_loop = data.TrialHandler(nReps=nTest, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='Test_loop')
    thisExp.addLoop(Test_loop)  # add the loop to the experiment
    thisTest_loop = Test_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb=thisTest_loop.rgb)
    if thisTest_loop != None:
        for paramName in thisTest_loop.keys():
            exec(paramName + '= thisTest_loop.' + paramName)
    
    for thisTest_loop in Test_loop:
        currentLoop = Test_loop
        # abbreviate parameter names if possible (e.g. rgb = thisTest_loop.rgb)
        if thisTest_loop != None:
            for paramName in thisTest_loop.keys():
                exec(paramName + '= thisTest_loop.' + paramName)
        
        #------Prepare to start Routine "Test"-------
        t = 0
        TestClock.reset()  # clock 
        frameN = -1
        routineTimer.add(17.000000)
        # update component parameters for each repeat
        image_3.setImage(Img)
        Test_Resp = event.BuilderKeyResponse()  # create an object of type KeyResponse
        Test_Resp.status = NOT_STARTED
        
        Test_Resp.rt=15
        Test_Resp.corr=0
        # keep track of which components have finished
        TestComponents = []
        TestComponents.append(test_start_txt)
        TestComponents.append(image_3)
        TestComponents.append(Test_Resp)
        TestComponents.append(Timer)
        for thisComponent in TestComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        #-------Start Routine "Test"-------
        continueRoutine = True
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = TestClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            # *test_start_txt* updates
            if t >= 0.0 and test_start_txt.status == NOT_STARTED:
                # keep track of start time/frame for later
                test_start_txt.tStart = t  # underestimates by a little under one frame
                test_start_txt.frameNStart = frameN  # exact frame index
                test_start_txt.setAutoDraw(True)
            if test_start_txt.status == STARTED and t >= (0.0 + (2-win.monitorFramePeriod*0.75)): #most of one frame period left
                test_start_txt.setAutoDraw(False)
            
            # *image_3* updates
            if t >= 2 and image_3.status == NOT_STARTED:
                # keep track of start time/frame for later
                image_3.tStart = t  # underestimates by a little under one frame
                image_3.frameNStart = frameN  # exact frame index
                image_3.setAutoDraw(True)
            if image_3.status == STARTED and t >= (2 + (15-win.monitorFramePeriod*0.75)): #most of one frame period left
                image_3.setAutoDraw(False)
            
            # *Test_Resp* updates
            if t >= 2 and Test_Resp.status == NOT_STARTED:
                # keep track of start time/frame for later
                Test_Resp.tStart = t  # underestimates by a little under one frame
                Test_Resp.frameNStart = frameN  # exact frame index
                Test_Resp.status = STARTED
                # keyboard checking is just starting
                win.callOnFlip(Test_Resp.clock.reset)  # t=0 on next screen flip
                event.clearEvents(eventType='keyboard')
            if Test_Resp.status == STARTED and t >= (2 + (15-win.monitorFramePeriod*0.75)): #most of one frame period left
                Test_Resp.status = STOPPED
            if Test_Resp.status == STARTED:
                theseKeys = event.getKeys(keyList=['left', 'right'])
                
                # check for quit:
                if "escape" in theseKeys:
                    endExpNow = True
                if len(theseKeys) > 0:  # at least one key was pressed
                    Test_Resp.keys = theseKeys[-1]  # just the last key pressed
                    Test_Resp.rt = Test_Resp.clock.getTime()
                    # was this 'correct'?
                    if (Test_Resp.keys == str(CorrKey)) or (Test_Resp.keys == CorrKey):
                        Test_Resp.corr = 1
                    else:
                        Test_Resp.corr = 0
                    # a response ends the routine
                    continueRoutine = False
            
            # *Timer* updates
            if t >= 12 and Timer.status == NOT_STARTED:
                # keep track of start time/frame for later
                Timer.tStart = t  # underestimates by a little under one frame
                Timer.frameNStart = frameN  # exact frame index
                Timer.setAutoDraw(True)
            if Timer.status == STARTED and t >= (12 + (5-win.monitorFramePeriod*0.75)): #most of one frame period left
                Timer.setAutoDraw(False)
            if Timer.status == STARTED:  # only update if being drawn
                Timer.setText(timer, log=False)
            
            timer = '%d' % routineTimer.getTime()
            
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in TestComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        #-------Ending Routine "Test"-------
        for thisComponent in TestComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        # check responses
        if Test_Resp.keys in ['', [], None]:  # No response was made
           Test_Resp.keys=None
           # was no response the correct answer?!
           if str(CorrKey).lower() == 'none': Test_Resp.corr = 1  # correct non-response
           else: Test_Resp.corr = 0  # failed to respond (incorrectly)
        # store data for Test_loop (TrialHandler)
        Test_loop.addData('Test_Resp.keys',Test_Resp.keys)
        Test_loop.addData('Test_Resp.corr', Test_Resp.corr)
        if Test_Resp.keys != None:  # we had a response
            Test_loop.addData('Test_Resp.rt', Test_Resp.rt)
        
        data_string += '%d,%.3f,%d\n' % (probNum, Test_Resp.rt, Test_Resp.corr)
        
        routineTimer.reset()
    # completed nTest repeats of 'Test_loop'
    
    
    # set up handler to look after randomisation of conditions etc
    mouse_loop = data.TrialHandler(nReps=nMouse, method='sequential', 
        extraInfo=expInfo, originPath=-1,
        trialList=[None],
        seed=None, name='mouse_loop')
    thisExp.addLoop(mouse_loop)  # add the loop to the experiment
    thisMouse_loop = mouse_loop.trialList[0]  # so we can initialise stimuli with some values
    # abbreviate parameter names if possible (e.g. rgb=thisMouse_loop.rgb)
    if thisMouse_loop != None:
        for paramName in thisMouse_loop.keys():
            exec(paramName + '= thisMouse_loop.' + paramName)
    
    for thisMouse_loop in mouse_loop:
        currentLoop = mouse_loop
        # abbreviate parameter names if possible (e.g. rgb = thisMouse_loop.rgb)
        if thisMouse_loop != None:
            for paramName in thisMouse_loop.keys():
                exec(paramName + '= thisMouse_loop.' + paramName)
        
        #------Prepare to start Routine "MouseEvent"-------
        t = 0
        MouseEventClock.reset()  # clock 
        frameN = -1
        routineTimer.add(0.100000)
        # update component parameters for each repeat
        MouseClick(xPos,yPos)
        
        if(TestType == "CloseSession"):
            EnterPress()
            EnterPress()
        
        # keep track of which components have finished
        MouseEventComponents = []
        MouseEventComponents.append(text)
        for thisComponent in MouseEventComponents:
            if hasattr(thisComponent, 'status'):
                thisComponent.status = NOT_STARTED
        
        #-------Start Routine "MouseEvent"-------
        continueRoutine = True
        while continueRoutine and routineTimer.getTime() > 0:
            # get current time
            t = MouseEventClock.getTime()
            frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
            # update/draw components on each frame
            
            
            # *text* updates
            if t >= 0.0 and text.status == NOT_STARTED:
                # keep track of start time/frame for later
                text.tStart = t  # underestimates by a little under one frame
                text.frameNStart = frameN  # exact frame index
                text.setAutoDraw(True)
            if text.status == STARTED and t >= (0.0 + (0.1-win.monitorFramePeriod*0.75)): #most of one frame period left
                text.setAutoDraw(False)
            
            # check if all components have finished
            if not continueRoutine:  # a component has requested a forced-end of Routine
                break
            continueRoutine = False  # will revert to True if at least one component still running
            for thisComponent in MouseEventComponents:
                if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                    continueRoutine = True
                    break  # at least one component has not yet finished
            
            # check for quit (the Esc key)
            if endExpNow or event.getKeys(keyList=["escape"]):
                core.quit()
            
            # refresh the screen
            if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
                win.flip()
        
        #-------Ending Routine "MouseEvent"-------
        for thisComponent in MouseEventComponents:
            if hasattr(thisComponent, "setAutoDraw"):
                thisComponent.setAutoDraw(False)
        
    # completed nMouse repeats of 'mouse_loop'
    
    thisExp.nextEntry()
    
# completed 1 repeats of 'trials'


#------Prepare to start Routine "end_test"-------
t = 0
end_testClock.reset()  # clock 
frameN = -1
# update component parameters for each repeat



filename = 'data/%s_%s.csv' %(expInfo['participant'], expInfo['date'])

with open(filename, 'wb') as fd:
    fd.write(data_string)

data = pd.read_csv(filename)

print data

data = data[data['rt'] <15] 

mrt = data.loc[:,'rt']
correct = data.loc[:, 'corr']

print "\n % correct        :", 100 * correct.mean()
print "overall speed (s):", float(mrt.mean())


# keep track of which components have finished
end_testComponents = []
for thisComponent in end_testComponents:
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED

#-------Start Routine "end_test"-------
continueRoutine = True
while continueRoutine:
    # get current time
    t = end_testClock.getTime()
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in end_testComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # check for quit (the Esc key)
    if endExpNow or event.getKeys(keyList=["escape"]):
        core.quit()
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

#-------Ending Routine "end_test"-------
for thisComponent in end_testComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)

# the Routine "end_test" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()








# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort() # or data files will save again on exit
win.close()
core.quit()
